﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jhermansen_compentency_exam
{
    class Program
    {
        static void Main(string[] args)
        {
            int answer = 0;
            Console.WriteLine("-------");
            Console.WriteLine("1. Conditionals");
            Console.WriteLine("2. For Loops");
            Console.WriteLine("3. While Loops");
            Console.WriteLine("4. Arrays");
            Console.WriteLine("5. Lists");
            Console.WriteLine("-1. Exit");
            Console.WriteLine("-------");
            int g = 0;
            int r = 0;
            do
            {
                answer = int.Parse(Console.ReadLine());
                if (answer == 1)
                {
                    Console.WriteLine("insert Grade Level 1-12");
                    g = int.Parse(Console.ReadLine());
                    Console.WriteLine("insert Reading Level 1-12");
                    r = int.Parse(Console.ReadLine());
                    if (g >= 9 && r >= 9)
                    {
                        Console.WriteLine("you are in highschool and are proficient in highschool reading");
                    }
                    else if (g <= 8 && r >= 9)
                    {
                        Console.WriteLine("you are not in highschool but are proficient in highschool reading");
                    }
                    else if (g >= 9 && r <= 8)
                    {
                        Console.WriteLine("you are in highschool but not proficient in highschool reading");
                    }
                    else if (g <= 8 && r <= 8)
                        Console.WriteLine("You are not in highschool and are not proficient in highschool reading");
                }
                if (answer == 3)
                {

                    int[] number = new int[10];
                    int scoreCnt = 0;
                    string inValue;
                    Console.Write("/Enter number {0}/ " + "/0 to exit/ " + "/up to 10 numbers/ : ", scoreCnt + 1);
                    inValue = Console.ReadLine();


                    while (inValue != "0")
                    {
                        number[scoreCnt] = Convert.ToInt32(inValue);
                        scoreCnt++;
                        Console.Write("Enter number {0}: ", scoreCnt + 1);
                        inValue = Console.ReadLine();
                    }

                    Console.WriteLine("Total numbers inserted: " + scoreCnt);
                    Console.WriteLine("The sum of the numbers: ");                          
                }
                    Console.Read();
                
                if (answer == 2)
                
                if (answer == 4)
                {
                   
                }
                if (answer == 5)
                {
                   
                }
            } while (answer != -1);
        }
    }
}
